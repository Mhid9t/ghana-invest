const { body, validationResult } = require('express-validator');

const validateRegistration = [
  body('name').trim().isLength({ min: 2, max: 50 }).escape(),
  body('phone').matches(/^0\d{9}$/).withMessage('Invalid phone number'),
  body('password').isLength({ min: 8 }).withMessage('Password must be at least 8 characters'),
  (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: errors.array()
      });
    }
    next();
  }
];

const validateInvestment = [
  body('amount').isFloat({ min: 100, max: 10000 }),
  body('planId').isIn(['starter', 'basic', 'silver', 'gold', 'platinum', 'diamond', 'executive', 'premium', 'elite', 'legacy']),
  (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }
    next();
  }
];

module.exports = { validateRegistration, validateInvestment };