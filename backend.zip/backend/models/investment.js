const mongoose = require('mongoose');

const InvestmentSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.ObjectId,
    ref: 'User',
    required: true
  },
  planName: {
    type: String,
    required: true,
    enum: ['Starter', 'Basic', 'Silver', 'Gold', 'Platinum', 'Diamond', 'Executive', 'Premium', 'Elite', 'Legacy']
  },
  amount: {
    type: Number,
    required: [true, 'Please add an investment amount'],
    min: [100, 'Minimum investment is GHS 100']
  },
  dailyReturn: {
    type: Number,
    required: true
  },
  totalReturn: {
    type: Number,
    required: true
  },
  duration: {
    type: Number,
    default: 30
  },
  startDate: {
    type: Date,
    default: Date.now
  },
  endDate: {
    type: Date,
    required: true
  },
  status: {
    type: String,
    enum: ['active', 'completed', 'cancelled'],
    default: 'active'
  },
  returnsPaid: {
    type: Number,
    default: 0
  },
  lastPayout: {
    type: Date
  }
}, {
  timestamps: true
});

// Calculate end date before saving
InvestmentSchema.pre('save', function(next) {
  if (this.isNew) {
    const endDate = new Date(this.startDate);
    endDate.setDate(endDate.getDate() + this.duration);
    this.endDate = endDate;
  }
  next();
});

module.exports = mongoose.model('Investment', InvestmentSchema);