const express = require('express');
const Investment = require('../models/investment');
const User = require('../models/user');
const Transaction = require('../models/transaction');
const { protect } = require('../middleware/auth');

const router = express.Router();

// Investment plans configuration
const investmentPlans = {
  'starter': { minAmount: 100, dailyReturn: 5, duration: 30 },
  'basic': { minAmount: 200, dailyReturn: 10, duration: 30 },
  'silver': { minAmount: 300, dailyReturn: 15, duration: 30 },
  'gold': { minAmount: 500, dailyReturn: 25, duration: 30 },
  'platinum': { minAmount: 800, dailyReturn: 40, duration: 30 },
  'diamond': { minAmount: 1000, dailyReturn: 50, duration: 30 },
  'executive': { minAmount: 1500, dailyReturn: 75, duration: 30 },
  'premium': { minAmount: 2000, dailyReturn: 100, duration: 30 },
  'elite': { minAmount: 3000, dailyReturn: 150, duration: 30 },
  'legacy': { minAmount: 5000, dailyReturn: 250, duration: 30 }
};

// @desc    Get all investment plans
// @route   GET /api/investments/plans
// @access  Public
router.get('/plans', (req, res) => {
  const plans = Object.entries(investmentPlans).map(([name, plan]) => ({
    name: name.charAt(0).toUpperCase() + name.slice(1) + ' Plan',
    id: name,
    minAmount: plan.minAmount,
    dailyReturn: plan.dailyReturn,
    duration: plan.duration,
    totalReturn: plan.dailyReturn * plan.duration
  }));

  res.status(200).json({
    success: true,
    plans
  });
});

// @desc    Create new investment
// @route   POST /api/investments
// @access  Private
router.post('/', protect, async (req, res) => {
  try {
    const { planId, amount } = req.body;

    // Check if plan exists
    const plan = investmentPlans[planId];
    if (!plan) {
      return res.status(400).json({
        success: false,
        message: 'Invalid investment plan'
      });
    }

    // Check minimum amount
    if (amount < plan.minAmount) {
      return res.status(400).json({
        success: false,
        message: `Minimum investment for ${planId} plan is GHS ${plan.minAmount}`
      });
    }

    // Check user balance
    const user = await User.findById(req.user.id);
    if (user.balance < amount) {
      return res.status(400).json({
        success: false,
        message: 'Insufficient balance'
      });
    }

    // Calculate total return
    const totalReturn = plan.dailyReturn * plan.duration;

    // Create investment
    const investment = await Investment.create({
      user: req.user.id,
      planName: planId.charAt(0).toUpperCase() + planId.slice(1),
      amount,
      dailyReturn: plan.dailyReturn,
      totalReturn,
      duration: plan.duration
    });

    // Update user balance
    user.balance -= amount;
    await user.save();

    // Create transaction record
    await Transaction.create({
      user: req.user.id,
      type: 'investment',
      amount: amount,
      description: `Investment in ${investment.planName} Plan`,
      status: 'completed',
      balanceBefore: user.balance + amount,
      balanceAfter: user.balance
    });

    res.status(201).json({
      success: true,
      message: 'Investment created successfully',
      investment: {
        id: investment._id,
        planName: investment.planName,
        amount: investment.amount,
        dailyReturn: investment.dailyReturn,
        totalReturn: investment.totalReturn,
        startDate: investment.startDate,
        endDate: investment.endDate
      },
      newBalance: user.balance
    });

  } catch (error) {
    console.error(error);
    res.status(500).json({
      success: false,
      message: 'Error creating investment'
    });
  }
});

// @desc    Get user's investments
// @route   GET /api/investments/my-investments
// @access  Private
router.get('/my-investments', protect, async (req, res) => {
  try {
    const investments = await Investment.find({ user: req.user.id })
      .sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      count: investments.length,
      investments
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      success: false,
      message: 'Error fetching investments'
    });
  }
});

// @desc    Get single investment
// @route   GET /api/investments/:id
// @access  Private
router.get('/:id', protect, async (req, res) => {
  try {
    const investment = await Investment.findOne({
      _id: req.params.id,
      user: req.user.id
    });

    if (!investment) {
      return res.status(404).json({
        success: false,
        message: 'Investment not found'
      });
    }

    res.status(200).json({
      success: true,
      investment
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      success: false,
      message: 'Error fetching investment'
    });
  }
});

module.exports = router;