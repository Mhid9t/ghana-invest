const express = require('express');
const Transaction = require('../models/transaction');
const User = require('../models/user');
const { protect } = require('../middleware/auth');

const router = express.Router();

// @desc    Process withdrawal
// @route   POST /api/transactions/withdraw
// @access  Private
router.post('/withdraw', protect, async (req, res) => {
  try {
    const { amount, network, phone } = req.body;

    // Validate input
    if (!amount || !network || !phone) {
      return res.status(400).json({
        success: false,
        message: 'Please provide amount, network, and phone number'
      });
    }

    // Validate phone number
    const phoneRegex = /^0\d{9}$/;
    if (!phoneRegex.test(phone)) {
      return res.status(400).json({
        success: false,
        message: 'Please provide a valid phone number'
      });
    }

    // Check minimum withdrawal
    if (amount < 100) {
      return res.status(400).json({
        success: false,
        message: 'Minimum withdrawal amount is GHS 100'
      });
    }

    // Check daily limit
    if (amount > 5000) {
      return res.status(400).json({
        success: false,
        message: 'Maximum withdrawal amount is GHS 5,000 per day'
      });
    }

    // Check user balance
    const user = await User.findById(req.user.id);
    if (user.balance < amount) {
      return res.status(400).json({
        success: false,
        message: 'Insufficient balance'
      });
    }

    const balanceBefore = user.balance;

    // Update user balance
    user.balance -= amount;
    await user.save();

    // Create withdrawal transaction
    const transaction = await Transaction.create({
      user: req.user.id,
      type: 'withdrawal',
      amount: amount,
      description: `Withdrawal to ${network} (${phone})`,
      status: 'completed',
      mobileNetwork: network,
      phoneNumber: phone,
      balanceBefore: balanceBefore,
      balanceAfter: user.balance
    });

    res.status(200).json({
      success: true,
      message: 'Withdrawal processed successfully',
      transaction: {
        id: transaction._id,
        amount: transaction.amount,
        network: transaction.mobileNetwork,
        phone: transaction.phoneNumber,
        status: transaction.status,
        date: transaction.createdAt
      },
      newBalance: user.balance
    });

  } catch (error) {
    console.error(error);
    res.status(500).json({
      success: false,
      message: 'Error processing withdrawal'
    });
  }
});

// @desc    Get user's transactions
// @route   GET /api/transactions
// @access  Private
router.get('/', protect, async (req, res) => {
  try {
    const transactions = await Transaction.find({ user: req.user.id })
      .sort({ createdAt: -1 })
      .limit(50);

    res.status(200).json({
      success: true,
      count: transactions.length,
      transactions
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      success: false,
      message: 'Error fetching transactions'
    });
  }
});

// @desc    Get user balance
// @route   GET /api/transactions/balance
// @access  Private
router.get('/balance', protect, async (req, res) => {
  try {
    const user = await User.findById(req.user.id);

    res.status(200).json({
      success: true,
      balance: user.balance,
      currency: 'GHS'
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      success: false,
      message: 'Error fetching balance'
    });
  }
});

module.exports = router;