const request = require('supertest');
const app = require('../server');

describe('GhanaInvest API Tests', () => {
  test('Health check endpoint', async () => {
    const response = await request(app).get('/api/health');
    expect(response.status).toBe(200);
    expect(response.body.success).toBe(true);
  });

  test('Investment plans endpoint', async () => {
    const response = await request(app).get('/api/investments/plans');
    expect(response.status).toBe(200);
    expect(response.body.plans).toBeInstanceOf(Array);
  });
});