const autocannon = require('autocannon');

async function loadTest() {
  const instance = autocannon({
    url: 'http://localhost:5000',
    connections: 10, // Number of concurrent connections
    duration: 10, // Test duration in seconds
    requests: [
      {
        method: 'GET',
        path: '/api/health'
      }
    ]
  });

  autocannon.track(instance);
}

loadTest();